//
//  DekD_HWApp.swift
//  DekD_HW
//
//  Created by Jirunthanin Kittiwiriya on 28/1/2565 BE.
//

import SwiftUI

@main
struct DekD_HWApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
