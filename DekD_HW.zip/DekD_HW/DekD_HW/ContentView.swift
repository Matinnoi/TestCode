//
//  ContentView.swift
//  DekD_HW
//
//  Created by Jirunthanin Kittiwiriya on 28/1/2565 BE.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            Form{
                List{
                    //1
                    Text("โพยเตรียมสอบ")
                        .font(.system(size: 18, weight: .heavy, design: .default))
                    Text("อวดโพยเชิญทู้นี้! ส่อง \"โพยเตรียมสอบ\" ในวิถีเซียน ละเอียดชนิดหมูบดยังต้องยอมแพ้")
                        .padding()
                    //2
                    Text("งาน #VMAs")
                        .font(.system(size: 18, weight: .heavy, design: .default))
                    Text("มาดูกัน งาน #VMAs ปีนี้ P!nk สอนอะไรเรา")
                        .padding()
                    //3
                    Text("ซุปกิมจิที่ไหนอร่อย?")
                        .font(.system(size: 18, weight: .heavy, design: .default))
                    Text("ซุปกิมจิที่ไหนอร่อย? ก็ซุปกิมจิที่ทำกินเองไง")
                        .padding()
                    //4
                    Text("เฟรชชี่ปี1")
                        .font(.system(size: 18, weight: .heavy, design: .default))
                    Text("เปิดวาร์ปเฟรชชี่ปี1")
                        .padding()
                    //5
                    Text("บุกกองซีรีส์คุณพ่อบรู๊ค")
                        .font(.system(size: 18, weight: .heavy, design: .default))
                    Text("น้องณดาน่ารักมาก!! บุกกองซีรีส์คุณพ่อบรู๊ค")
                        .padding()
                }
            }
            .navigationBarItems(leading:
                                    Button(action: {
                                        print("Back button pressed...")
                                    }) {
                                        Text(" ")
                                            .font(.system(size:15))
                                    },
                    trailing:
                        Button(action: {
                            print("Edit button pressed...")
                        }) {
                            NavigationLink(destination: AddContent()){
                                Text("+")
                                .font(.system(size:30))}
                        }
                )
            .navigationBarTitle("Dek-D แชร์เยอะ", displayMode: .inline)
        }
    }
}
struct AddContent: View {
    @State var headcontent: String = ""
    @State var ddetail: String = ""
    var body: some View {
            VStack(alignment: .leading) {
                    TextField("หัวข้อบทความ", text: $headcontent)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                    TextField("เนื้อหา", text: $ddetail)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                Button {
                    print("Button pressed")
                        
                } label: {
                    Text("OK")
                        .padding()
                        .frame(alignment: .center)
                }
                    }
        }
    }
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        AddContent()
    }
}
